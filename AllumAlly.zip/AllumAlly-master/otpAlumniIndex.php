<?php
session_start();
 if (isset($_SESSION['message'])) {
   echo '<script type="text/javascript">alert("' . $_SESSION['message'] . '");</script>';
   unset($_SESSION['message']);
}
if (isset($_SESSION['m'])) {
   echo '<script type="text/javascript">alert("' . $_SESSION['m'] . '");</script>';
   unset($_SESSION['m']);
}
if(isset($_SESSION['send']))
{
  header("Refresh: 0");
  unset($_SESSION['send']);
}
 
if(isset($_SESSION['otp']))
{

?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Allum Ally</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  <link href="/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  
  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

</head>

<body>

  <!--==========================
    Header
  ============================-->
  
  <header id="header">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        <h1><a href="#intro" class="scrollto">AllumAlly</a></h1>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">Home</a></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#contact">Contact</a></li>
		  <li><div class="dropdown">
		  <button class="dropbtn">My Account</button>
		  <div class="dropdown-content">
			<a id="change" style="color: black;">Change Password</a>
			<a href="logout.php">Logout</a>
		  </div>
</div></li>
</ul>
   </nav><!-- #nav-menu-container -->
  </div>

<div id="otps" class="modalotp">
    <div class="modal2-content">
      <span class="close">&times;</span><br>
        <form name="frmChange" method="post" action="alumniaction.php">
          <table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">
              <tr>
                <td><label style="font-family:'Times New Roman'; font-size: 17px;">OTP </label></td>
                <td><input type="password" name="otp" class="txtField" style="width: 100%;height: 40px;padding: 10px;margin: 5px 0 15px 0;display: inline-block;border: 1px solid #BCBCBC;background: white;" required/></td>
                </tr>
              <tr>
                    <td><p style="font-family:'Times New Roman'; color: brown; font-size: 13px;">(Check your mail for OTP)</p></td>
                </tr>
              <tr>
                    <td colspan="2"><button type="submit" class="submitbtn">Submit</button></td>
                </tr>
              </table>
        </form>
    </div>
  </div>

  </header><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">

      
		<!--<ol class="carousel-indicators"></ol>-->

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active">
		 
            <div class="carousel-background"><img src="./3.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Alumni Connect!</h2>
                <p>Alumni are a great resource every educational institution can take pride in. Often the students of an
institute seek professional help from their alumni. Be it a job referral or a friendly face in a fairly
strange place of work, alumni comes to help. </p><p>It would be easier to connect with alumni if latest details are provided and we sincerely appreciate you for taking time to update your details on the site.</p>
                <a id="update" class="btn-get-started scrollto">Update Profile</a>
              </div>
            </div>
          </div>

        </div>

        
      </div>
    </div>
  </section><!-- #intro -->

  <main id="main">

    <!--==========================
      Featured Services Section
    ============================-->
    <section id="featured-services">
      <div class="container">
        <div class="row">

          <div class="col-lg-12 box box-bg">
            <i class="ion-ios-people"></i>
            <h4 class="title"><a>Re-union</a></h4>
            <p class="description">Your splendid work at the institute can help your juniors or the staff members to get in touch with you in the recent times. Having your details updated here can make them to reach you out faster without the help of anyothers. They can seek professional help from you as well as maintain personal relations.</p>
          </div>
    </section><!-- #featured-services -->

    <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

        <header class="section-header">
          <h3>About Us</h3>
          <p>Allum Ally helps you to re-build network with your juniors and staff. This website helps in connecting the current members of Vasireddy Venkatadri Institute of Technology with the alumni. The records of you available the institute at the time of your graduation are considered and we request you to update your details. 
		  </p>
        </header>

        <div class="row about-cols">

          <div class="col-md-6 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                <img src="img/mission3.jpeg" style="width:100%;" alt="Image unavailable" class="img-fluid">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Mission</a></h2>
              <p>A group of members collaborate to strengthen both the alumni relations and the upcoming placements of the undergraduates.
              </p>
            </div>
          </div>

          <div class="col-md-6 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                <img src="img/vision2.jpeg" style="width:100%;" alt="Image unavailable" class="img-fluid">
                <div class="icon"><i class="ion-ios-eye-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Vision</a></h2>
              <p>A platform based on building a relationship with the alumni of the respective institute.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      Contact Section
    ============================-->
    <section id="contact" class="section-bg wow fadeInUp">
      <div class="container">

        <div class="section-header">
          <h3>Contact Us</h3>
        </div>

        <div class="row contact-info">
		
          <div class="col-md-6">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855">+91 9435789685</a></p>
            </div>
          </div>

          <div class="col-md-6">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="mailto:info@example.com">username@gmail.com</a></p>
            </div>
          </div>

        </div>
		
		    <div class="section-header">
          <h3>Drop a message</h3>
        </div>

        <div class="form">
          <form action="./secure_email.php" method="post" class="contactForm">
            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter your name" required />
                <div class="validation"></div>
              </div>
        
             <div class="form-group col-md-6">
                <input type="email" name="email" class="form-control" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required />
                <div class="validation"></div>
              </div>
  
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required />
              <div class="validation"></div>
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" required></textarea>
              <div class="validation"></div>
            </div>
            <div class="text-center"><button name='submit' type="submit" value="Submit">Send</button></div>
          </form>
          
        </div>
      </div>
    </section><!-- #contact -->

  </main>

  <!--==========================
    Footer
  ============================-->
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-2 col-md-6 social-links">
             <a href="mailto:alumniupdates2020@gmail.com" class="google-plus"><i class="fa fa-google-plus"></i></a>
          </div>


          <div class="col-lg-8 col-md-6">
             <div class="container">
          <div class="copyright">
             &copy; 2020 <strong>AllumAlly</strong>. All Rights Reserved
          </div>
        </div>
          </div>

          <div class="col-lg-2 col-md-6">
            <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
        </div>
      </div>
    </div>

   
  </footer><!-- #footer -->


  
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/touchSwipe/jquery.touchSwipe.min.js"></script>
  <!-- Contact Form JavaScript File -->

    <script>
  function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}

// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("update");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close3")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

function myFunction(a) {
  var x = document.getElementById("pwd");
  if (x.type == "password") {
    x.type = "text";
    a.toggleClass('fa fa-eye-slash');
  } else {
    x.type = "password";
    a.toggleClass("fa fa-eye");
  }
}
  

// Get the modal
var modal1 = document.getElementById("myModal1");

// Get the button that opens the modal
var btn1 = document.getElementById("change");

// Get the <span> element that closes the modal
var span1 = document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn1.onclick = function() {
  modal1.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span1.onclick = function() {
  modal1.style.display = "none";
}
  
window.onclick = function(event) {
  if ((event.target == modal) || (event.target == modal1)) {
    modal.style.display = "none";
    modal1.style.display = "none";
  }
}
  </script>


  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>

<?php } 

else {
  echo '<script language="javascript">';
  echo 'window.location.href="index.php";';
  echo '</script>';
}

?>
