<?php
session_start();
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="alumni"; // Database name 
$tbl_name="alumnidetails"; // Table name
// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{

	// Define $myusername and $mypassword 
	$myusername=$_POST['email']; 
	$mypassword=$_POST['pwd'];

	// To protect MySQL injection (more detail about MySQL injection)
	$myusername = stripslashes($myusername);
	$mypassword = stripslashes($mypassword);
	
	$sql="SELECT * FROM $tbl_name WHERE email='$myusername' and pwd='$mypassword'";
	$result=mysqli_query($con,$sql);

	// Mysqli_num_row is counting table row
	$count=mysqli_num_rows($result);

	// If result matched $myusername and $mypassword, table row must be 1 row
	if($count==1)
	{
		$_SESSION['user'] = $myusername;
		header("location:alumniIndex.php");
	}
	else 
	{
		$sql="SELECT email from $tbl_name where email='$myusername'";
		$result=mysqli_query($con,$sql);

		// Mysqli_num_row is counting table row
		$count=mysqli_num_rows($result);
		
		if($count==1)
			$_SESSION['errormsg'] = 'Incorrect Password!';
		else
			$_SESSION['errormsg'] = 'User Id not available! Please contact the admin.';
		header("location:userIndex.php");
	}
}
?>
