<?php 
session_start();
session_destroy();
unset($_SESSION['user']);
echo '<script language="javascript">';
echo 'window.location.href="index.php";';
echo '</script>';
?>