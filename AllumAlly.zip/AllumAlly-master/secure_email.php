<?php
require_once "Mail.php";
$host1 = "ssl://smtp.gmail.com";
	$from = "alumniupdates2020@gmail.com";
	$to = "alumniupdates2020@gmail.com";
	$port = "465";
	$username = 'alumniupdates2020@gmail.com';
	$password = 'alumni2020';
session_start();
	if(isset($_POST['submit'])){
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = '<pre><p style="font-size:16px;">Name:  '.$_POST['name'].'</p><br><p style="font-size:16px;">Email:  '.$email.'</p><br><p style="font-size:16px;">Message:<br><br>'.$_POST['message'].'</p></pre>';
$message = wordwrap($message, 70);
$headers = array ('From' => $from, 'To' => $to,'Subject' => $subject, 'MIME-Version' => '1.0','Content-Type' => 'text/html; charset=iso-8859-1');
$smtp = Mail::factory('smtp', array ('host' => $host1, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password));
$mail = $smtp->send($email, $headers, $message);
$flag=0;	
$_SESSION['send']=1;
if (PEAR::isError($mail)) 
{
    echo "<script>
             alert('Message could not be sent. Please try again later!'); 
             window.history.go(-1);
     </script>";
}
else
{	echo "<script>
             alert('Message sent succesfully!'); 
             window.history.go(-1);
     </script>";
 }
}
?>
