<html>
	<link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
	<link href="/apple-touch-icon.png" rel="apple-touch-icon">

	<?php
	session_start();
	$name = $_GET['id'];
	echo $name;;
	?>

</html>

