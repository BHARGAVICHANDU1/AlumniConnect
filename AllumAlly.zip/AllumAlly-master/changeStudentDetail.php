<?php
session_start();
  if (isset($_SESSION['qstring'])) {
    echo '<script type="text/javascript">alert("' . $_SESSION['qstring'] . '");</script>';
    unset($_SESSION['qstring']);
}

if (isset($_SESSION['message'])) {
    echo '<script type="text/javascript">alert("' . $_SESSION['message'] . '");</script>';
    unset($_SESSION['message']);
}

if (isset($_SESSION['msg'])) {
    echo '<script type="text/javascript">alert("' . $_SESSION['msg'] . '");</script>';
    unset($_SESSION['msg']);
}

if(isset($_SESSION['user']))
{

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicons -->
  <link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  <link href="/apple-touch-icon.png" rel="apple-touch-icon">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
<link rel="stylesheet" href="css/cSDstyles.css">
<link rel="stylesheet" href="css/matrix-media.css">
<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="css/jquery.gritter.css">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>

<script> 
	function validateInsertForm() 
	{
		if (form.regno.value.length == 0
		&& form.name.value.length == 0
		&& form.email.value.length == 0
		&& form.phone.value.length == 0
		&& form.company.value.length == 0
		&& form.location.value.length == 0) 
		{
			alert( "You need to enter at least 1 field to conduct a search" );
			return false;
		}
		
	}
	
	function validateUpdateForm() 
	{
		if (form.regno.value.length == 0
		&& form.name.value.length == 0
		&& form.email.value.length == 0
		&& form.phone.value.length == 0
		&& form.company.value.length == 0
		&& form.location.value.length == 0) 
		{
			alert( "You need to enter at least 1 field to conduct a search" );
			return false;
		}
		
	}
 </script>

<body>

<!--Header-part-->
<div id="header">
</div>
<!--close-Header-part--> 

<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-tint"></i>Update Alumni Details</a>
  <ul>
    <li><a href="adminIndex.php"><i class="icon icon-home"></i> <span>Modify Users</span></a> </li>
    <li class="active"><a href="#"><i class="icon icon-tint"></i> <span>Update Alumni Details</span></a></li>
    <li><a href="send.php"><i class="icon-calendar"></i> <span>Alumni Reminder</span></a></li>
    <li><a id="change"><i class="icon icon-pencil"></i> <span>Change Password</span></a></li>
    <li><a href="index.php"><i class="icon icon-share-alt"></i> <span>Logout</span></a></li>
  </ul>
</div>
<!--sidebar-menu-->

<div id="myModal1" class="modal2">
  <div class="modal2-content">
    <span class="close2">&times;</span><br>

    <form name="frmChange" method="post" action="adminAction.php" onSubmit="return validatePassword()">
      <div style="width: 500px;">
            <div class="message">
              <?php if(isset($message)) { echo $message; } ?>
              </div>
            <table border="0" cellpadding="10" cellspacing="0"
                width="500" align="center" class="tblSaveForm">
                <tr class="tableheader">
                    <td colspan="2" style="font-family:'Times New Roman'; font-size: 20px; text-align: center; margin-left: 150px; line-height: 2"><strong>CHANGE PASSWORD</strong></td>
                </tr>
                <tr><td></td></tr>
                <tr>
                    <td><label style="font-family:'Times New Roman'; font-size: 17px;">Current Password</label></td>
                    <td><input type="password" name="currentPassword" id="currentPassword" class="txtField" maxlength="10" required/></td>
                </tr>
                <tr>
                <td><label style="font-family:'Times New Roman'; font-size: 17px;">New Password</label></td>
                <td><input id="pwd" type="password" name="newPassword" class="txtField" required/></td>
                </tr>
                <tr>
                  <td><i onclick="myFunction(this)" class="fa fa-eye" style="margin-left:100%;padding-left: 20px;"></i></td>
                </tr>
                <tr>
                <td><label style="font-family:'Times New Roman'; font-size: 17px;">Confirm New Password</label></td>
                <td><input type="password" name="confirmPassword" class="txtField" required/></td>
                </tr>
                <tr>
                    <td colspan="2"><button type="submit" class="submitbtn">Submit</button></td>
                </tr>
            </table>
        </div>
    </form>

</div>
</div>

<!--main-container-part-->
<div id="content">

<br><br>

<ul style="list-style-type:none;">
    <li>
    	<div class="dropdowns">
		  	<button class="open-button">Modify Alumni Details</button>
		  		<div class="dropdowns-content">
			  		<button class="open" id="myBtnA"><a>Insert</a></button>
			  		<button class="open" id="myBtnC"><a>Update</a></button>
			  	</div>
			</div>
    </li>
    <br>
    <li>
    	<p class="below">Details of a single student can be updated.</p>
    </li>
    <br><br><br>
    <li> <button class="open-button" id="csv">Insert through CSV file</button> </li>
	
	<p class="below1">Please note that the file should have six columns consisting of student's Register No, Name, E-mail,Phone No,Comapany Name and Location in the same order.</p>
	
	<br><br><br>
    <li> <button class="open-button" id="viewAlumni">View Alumni Details</button> </li>
 </ul>
 
<div id="myModalA" class="modalN">

  <!-- Modal content -->
  <div class="modal3-content">
    <span class="close">&times;</span><br>
	<form  name="form" action="./insertSD.php" method="post" onSubmit="return validateInsertForm()">
		<b>Register No</b>
		<input type="text" placeholder="Register No" name="regno" required><br>
	  	<b>Full Name</b>
		<input type="text" placeholder="Full name" name="name" required><br>
		<b>Email id</b><br>
		<input type="email" placeholder="Email id" name="email" required><br>
		<b>Phone</b><br>
		<input type="number" placeholder="Phone number" name="phone" required><br>
		<b>Company</b>
		<input type="text" placeholder="Company Name" name="company" required><br>
		<b>Location</b><br>
		<input type="text" placeholder="Location" name="location" required><br>
		<button type="submit" class="registerbtn">Submit</button>
		<button type="button" class="cancel" onclick="closeForm()">Cancel</button>
	</form>    
  </div>
</div>

<div id="myModalC" class="modal2">
<div class="modal1-content">
    <span class="close3">&times;</span><br>
	<form name="form2" action="./updateSD.php" method="post" onSubmit="return validateUpdateForm()">
	  	<!--<p class="below">*Enter the new email/phone number*</p><br>-->
	  	<b>Register No</b>
		<input type="text" placeholder="Register No" name="regno" required><br>
	  	<b>Full Name</b>
		<input type="text" placeholder="Full name" name="name"><br>
		<b>Email id</b><br>
		<input type="email" placeholder="Email id" name="email"><br>
		<b>Phone</b><br>
		<input type="number" placeholder="Phone number" name="phone"><br>
		<b>Company</b>
		<input type="text" placeholder="Company Name" name="company"><br>
		<b>Location</b><br>
		<input type="text" placeholder="Location" name="location"><br>
		<button type="submit" class="registerbtn">Submit</button>
		<button type="button" class="cancel" onclick="closeForm()">Cancel</button>
	</form>    
  </div>
</div>

  <div id="myModal" class="modal4">

  <!-- Modal content -->
  <div class="modal4-content">
    <span class="close1">&times;</span>
	
<!-- CSV file upload form -->
     <form action="importcsv.php" method="post" enctype="multipart/form-data">
            <input type="file" name="file">
            <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
      </form> 

  </div>

</div>

<!--Footer-part-->
  <footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="copyright">
         &copy; 2019 <strong>AllumAlly</strong>. All Rights Reserved
      </div>
  </div>
    </div>
  </footer><!-- #footer -->

<!--end-Footer-part-->

<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.dashboard.js"></script> 
<script src="js/jquery.gritter.min.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 

<script type="text/javascript">

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}

function validatePassword() {
      var currentPassword,newPassword,confirmPassword,output = true;

      currentPassword = document.frmChange.currentPassword;
      newPassword = document.frmChange.newPassword;
      confirmPassword = document.frmChange.confirmPassword;

      if(newPassword.value != confirmPassword.value) {
        newPassword.value="";
        confirmPassword.value="";
        newPassword.focus();
        document.getElementById("confirmPassword").innerHTML = "not same";
        $_SESSION['output'] = false;
      }   
}

//Modal A
// Get the modal
var modal = document.getElementById("myModalA");

// Get the button that opens the modal
var btn = document.getElementById("myBtnA");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// Get Modal1
var modal2 = document.getElementById("myModal1");

// Get the button that opens the modal
var btn2 = document.getElementById("change");

// Get the <span> element that closes the modal
var span2 = document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn2.onclick = function() {
  modal2.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span2.onclick = function() {
  modal2.style.display = "none";
}

//Modal C
// Get the modal
var modal3 = document.getElementById("myModalC");

// Get the button that opens the modal
var btn3 = document.getElementById("myBtnC");

// Get the <span> element that closes the modal
var span3 = document.getElementsByClassName("close3")[0];

// When the user clicks the button, open the modal 
btn3.onclick = function() {
  modal3.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span3.onclick = function() {
  modal3.style.display = "none";
}

//now to open Import using csv file ======

var modal1 = document.getElementById("myModal");

// Get the button that opens the modal
var btn1 = document.getElementById("csv");

// Get the <span> element that closes the modal
var span1 = document.getElementsByClassName("close1")[0];

// When the user clicks the button, open the modal 
btn1.onclick = function() {
  modal1.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span1.onclick = function() {
  modal1.style.display = "none";
}

var btn4 = document.getElementById('viewAlumni');
btn4.addEventListener('click', function() {
  document.location.href = './viewAlumniDetails.php';
});

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if ((event.target == modal) || (event.target == modal1)  || (event.target == modal3) || (event.target == modal2)) {
    modal.style.display = "none";
    modal1.style.display = "none";
    modal2.style.display = "none";
    modal3.style.display = "none";
  }
}

function closeForm() {
	  document.getElementById("myModalA").style.display = "none";
	  document.getElementById("myModalC").style.display = "none";
	}

  function myFunction(a) {
  var x = document.getElementById("pwd");
  if (x.type == "password") {
    x.type = "text";
    a.toggleClass('fa fa-eye-slash');
  } else {
    x.type = "password";
    a.toggleClass("fa fa-eye");
  }
}

</script>
</body>
</html>

<?php } 

else {
  echo '<script language="javascript">';
  echo 'window.location.href="index.php";';
  echo '</script>';
}

?>
