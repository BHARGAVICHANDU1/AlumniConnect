<?php
session_start();
if(isset($_SESSION['connect'])) {
  echo '<script type="text/javascript">alert("' . $_SESSION['connect'] . '");</script>';
    unset($_SESSION['connect']);
}
else {
  if(isset($_SESSION['add']))
  {
    echo '<script type="text/javascript">alert("' . "Mails sent successfully." . '");</script>';
    unset($_SESSION['add']);
  }
  if(isset($_SESSION['adderror']))
  {
    echo '<script type="text/javascript">alert("' . "Mails sent successfully but the timestamp of sending the mails could not be updated in the database." . '");</script>';
    unset($_SESSION['adderror']);
  }
  
  if (isset($_SESSION['error'])) {
    echo '<script type="text/javascript">alert("' . "Error sending mails to: ".$_SESSION['error'] . '");</script>';
    unset($_SESSION['error']);
  }
}

if(isset($_SESSION['user']))
{

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicons -->
  <link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  <link href="/apple-touch-icon.png" rel="apple-touch-icon">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
<link rel="stylesheet" href="css/cSDstyles.css">
<link rel="stylesheet" href="css/matrix-media.css">
<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="css/jquery.gritter.css">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>

<body>

<!--Header-part-->
<div id="header">
</div>
<!--close-Header-part--> 

<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-tint"></i>Alumni Reminder</a>
  <ul>
    <li><a href="adminIndex.php"><i class="icon icon-home"></i> <span>Modify Users</span></a> </li>
    <li><a href="changeStudentDetail.php"><i class="icon icon-tint"></i> <span>Update Alumni Details</span></a></li>
    <li class="active"><a href="#"><i class="icon-calendar"></i> <span>Alumni Reminder</span></a></li>
    <li><a id="change"><i class="icon icon-pencil"></i> <span>Change Password</span></a></li>
    <li><a href="logout.php"><i class="icon icon-share-alt"></i> <span>Logout</span></a></li>
  </ul>
</div>
<!--sidebar-menu-->

<div id="myModal1" class="modal2">
  <div class="modal2-content">
    <span class="close2">&times;</span><br>

    <form name="frmChange" method="post" action="adminAction.php" onSubmit="return validatePassword()">
      <div style="width: 500px;">
            <div class="message">
              <?php if(isset($message)) { echo $message; } ?>
              </div>
            <table border="0" cellpadding="10" cellspacing="0"
                width="500" align="center" class="tblSaveForm">
                <tr class="tableheader">
                    <td colspan="2" style="font-family:'Times New Roman'; font-size: 20px; text-align: center; margin-left: 150px; line-height: 2"><strong>CHANGE PASSWORD</strong></td>
                </tr>
                <tr><td></td></tr>
                <tr>
                    <td><label style="font-family:'Times New Roman'; font-size: 17px;">Current Password</label></td>
                    <td><input type="password" name="currentPassword" id="currentPassword" class="txtField" maxlength="10" required/></td>
                </tr>
                <tr>
                <td><label style="font-family:'Times New Roman'; font-size: 17px;">New Password</label></td>
                <td><input id="pwd" type="password" name="newPassword" class="txtField" required/></td>
                </tr>
                <tr>
                  <td><i onclick="myFunction(this)" class="fa fa-eye" style="margin-left:100%;padding-left: 20px;"></i></td>
                </tr>
                <tr>
                <td><label style="font-family:'Times New Roman'; font-size: 17px;">Confirm New Password</label></td>
                <td><input type="password" name="confirmPassword" class="txtField" required/></td>
                </tr>
                <tr>
                    <td colspan="2"><button type="submit" class="submitbtn">Submit</button></td>
                </tr>
            </table>
        </div>
    </form>

</div>
</div>
<div id="timeModal" class="modal2">
  <div class="modal2-content">
    <span class="close1">&times;</span><br>
   <?php
      $host="localhost"; // Host name 
      $username="root"; // Mysql username 
      $password=""; // Mysql password 
      $db_name="alumni"; // Database name 
      $tbl_name="mails"; // Table name
      // Connect to server and select databse.
      $con=mysqli_connect("$host", "$username", "$password", "$db_name");
      if (mysqli_connect_errno()) 
      {
        ?>
        <p style="font-size: 15px; font-family: Times New Roman;">There is an error connecting to the database. Please try again!</p>
        <?php
      }
      else
      { 
        $sql="SELECT * FROM $tbl_name";
        $result=mysqli_query($con,$sql);
        $count=mysqli_num_rows($result);
        if($count>0)
        {
        ?>
             <table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">
              <tr>
                <th style="font-size: 15px;">Reminder mails last sent were on:</th>
              </tr>
              <tr>
                <th style="text-align: left;">DATE</th>
                <th style="text-align: left;">TIME</th>
              </tr>
              <?php
              while($row=mysqli_fetch_array($result))
              {
              ?>
                <tr>
                  <td><?php echo $row['dates']; ?> </td>
                  <td><?php echo $row['dtime']; ?> </td>
                </tr>
              <?php 
              }
              ?>
             </table>
        <?php 
      }
      else
      {
        ?>
        <p style="font-size: 15px; font-family: Times New Roman;">No mails have been sent to the alumni till date. Start sending mails now.</p>
      <?php
      }
    }
      ?>
</div>
</div>



<!--main-container-part-->
<div id="content">

<br><br>

<div>

  <button id="time" style="margin-left: 50px; margin-bottom: 20px; background-color: black; color: white; font-family: Times New Roman; font-size: 15px;">Mails were last sent on</button>

	<form action="./sendingmail.php" method="post">
    <p style="margin-left: 50px;"><strong> Body of the mail </strong></p>
	<textarea style="margin-left: 100px; width: 80%;white-space: pre-line; height: 20%; padding-top: 3px; padding-left: 12px; padding-right: 10px; padding-bottom: 150px; font-size: 18px; font-family: Times New Roman;" name="message1" rows="5" cols="50">
Dear Alumni,

        Hello all! We hope you are doing great these days. Thank you for lightening up the name of VVIT at your work places. It is now time for your juniors to do as well. They have bright career opportunities coming ahead. Getting in touch with you can help them to gain awareness about the fields they want to work in. Building up connections with alumni plays a great advantage for both the students & the management.  

We request you to update your profile details by logging in the link provided below with these credentials -
   		
   		Login Id : your-mail
  		Password : abcd

The mail here would be the mail in our records. If you have any query, feel free to send a message from the contact form on the website.   	

    </textarea>

    <p style="margin-left: 50px;"><strong> Closing part </strong></p>

    <textarea style="margin-left: 100px;white-space: pre-line; padding-top: 3px; padding-left: 12px; padding-right: 10px; width: 80%; height: 20%; font-size: 18px; overflow:hidden; font-family: 'Times New Roman';" name="message3" rows="3" cols="50">
Regards,
VVIT.
    </textarea>
	
    <br><br>
		<button class="open-button1" value="submit">Send Reminder Mails</button>
    <br>
</form>
    <p class="below2">Sending a mail can act as a reminder for the alumni to update their details on the site which can help students & staff. Send the default information provided in the text area above or edit if needed.</p>
    <br><br><br>

</div>
</div>

<!--Footer-part-->
  <footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="copyright">
         &copy; 2019 <strong>AllumAlly</strong>. All Rights Reserved
      </div>
  </div>
    </div>
  </footer><!-- #footer -->

<script> 
  function validateInsertForm() 
  {
    if (form.regno.value.length == 0
    && form.name.value.length == 0
    && form.email.value.length == 0
    && form.phone.value.length == 0
    && form.company.value.length == 0
    && form.location.value.length == 0) 
    {
      alert( "You need to enter at least 1 field to conduct a search" );
      return false;
    }
    
  }
  
  function validateUpdateForm() 
  {
    if (form.regno.value.length == 0
    && form.name.value.length == 0
    && form.email.value.length == 0
    && form.phone.value.length == 0
    && form.company.value.length == 0
    && form.location.value.length == 0) 
    {
      alert( "You need to enter at least 1 field to conduct a search" );
      return false;
    }
    
  }

  function validatePassword() {
      var currentPassword,newPassword,confirmPassword,output = true;

      currentPassword = document.frmChange.currentPassword;
      newPassword = document.frmChange.newPassword;
      confirmPassword = document.frmChange.confirmPassword;

      if(newPassword.value != confirmPassword.value) {
        newPassword.value="";
        confirmPassword.value="";
        newPassword.focus();
        document.getElementById("frmChange").innerHTML = "not same";
        $_SESSION['output'] = false;
      }   
}

  // Get Modal1
var modal3 = document.getElementById("myModal1");

// Get the button that opens the modal
var btn3 = document.getElementById("change");

// Get the <span> element that closes the modal
var span3 = document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn3.onclick = function() {
  modal3.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span3.onclick = function() {
  modal3.style.display = "none";
}

var modal1 = document.getElementById("timeModal");

// Get the button that opens the modal
var btn1 = document.getElementById("time");

// Get the <span> element that closes the modal
var span1 = document.getElementsByClassName("close1")[0];

// When the user clicks the button, open the modal 
btn1.onclick = function() {
  modal1.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span1.onclick = function() {
  modal1.style.display = "none";
}


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if ((event.target == modal3) || (event.target == modal1)) {
    modal3.style.display = "none";
    modal1.style.display = "none";
  }
}

function myFunction(a) {
  var x = document.getElementById("pwd");
  if (x.type == "password") {
    x.type = "text";
    a.toggleClass('fa fa-eye-slash');
  } else {
    x.type = "password";
    a.toggleClass("fa fa-eye");
  }
}

 </script>


</body>
</html>

<?php } 

else {
  echo '<script language="javascript">';
  echo 'window.location.href="index.php";';
  echo '</script>';
}

?>
