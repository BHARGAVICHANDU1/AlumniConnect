<?php
session_start();  
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="alumni"; // Database name 
$tbl_name="alumnidetails"; // Table name
// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
	$sql="SELECT * FROM $tbl_name";
	
	$result=mysqli_query($con,$sql);

	// Mysqli_num_row is counting table row
	$count=mysqli_num_rows($result);
	 
	if($count>0)
	{
		?>
		<html>
		<link rel="stylesheet" type="text/css" href="usersTableStyles.css">
		<link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  		<link href="/apple-touch-icon.png" rel="apple-touch-icon">
  		<div class="limiter">
		<!--<div><a class="close2">Back</a><br></div>-->
		<div class="container-table100">
			<div class="wrap-table100">
					<div><a href="changeStudentDetail.php" class="close2">Back</a><br></div>
					<div class="table">
						<div class="row header">
							<div class="cell"> Register No </div>
							<div class="cell"> Name </div>
							<div class="cell"> Email </div>
							<div class="cell"> Phone No </div>
							<div class="cell"> Company </div>
							<div class="cell"> Location </div>
						</div>

						<?php
						while($row = mysqli_fetch_assoc($result)) {
						?>

       					<div class="row data">
							<div class="cell" data-title="userid">
								<?php  echo $row["userid"]  ?>
							</div>
							<div class="cell" data-title="name">
								<?php  echo $row["name"]  ?>
							</div>
							<div class="cell" data-title="email">
								<?php  echo $row["email"]  ?>
							</div>
							<div class="cell" data-title="phone">
								<?php  echo $row["phno"]  ?>
							</div>
							<div class="cell" data-title="company">
								<?php  echo $row["company"]  ?>
							</div>
							<div class="cell" data-title="location">
								<?php  echo $row["location"]  ?>
							</div>
						</div>
						<?php
							}
						?>
					</div>
				</div>
			</div>
		</div>
		</html>
		<?php
	}
	else 
	{
		//Sending API request
		session_start();
		$_SESSION['msg'] = "Could not process your request! Try again later.";
        header('Location: ./adminIndex.php');		
	}
}
?>