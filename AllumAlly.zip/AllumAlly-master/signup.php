<?php
ob_start();
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="alumni"; // Database name 
$tbl_name="users"; // Table name
// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
	
	// Define $email and $pwd 
	$email=$_POST['email']; 
	$pwd=$_POST['psw'];

	// To protect MySQL injection (more detail about MySQL injection)
	$pwd = stripslashes($pwd);
	$email = stripslashes($email);
	//$pwd = md5($pwd);
	//$pwd = mysql_real_escape_string($pwd);
	//$email = mysql_real_escape_string($email);

	$sql="SELECT * FROM $tbl_name WHERE email='$email' and pwd='$pwd'";
	$result=mysqli_query($con,$sql);

	// Mysql_num_row is counting table row
	$count=mysqli_num_rows($result);
	// If result matched $myusername and $mypassword, table row must be 1 row

	if($count==1)
	{
		echo "User already exists";
	}
	else 
	{
			$sql="insert into $tbl_name (email,pwd) values ('$email','$pwd')";
			mysqli_query($con,$sql);
			echo "Registration successful!<br><br>";
			//$_SESSION("$email")='email';
			//$_SESSION("$Spwd")='pwd';
			//session_register("pwd");
			header("location:index.php");
	}
	mysqli_close($con);
}
ob_end_flush();
?>


