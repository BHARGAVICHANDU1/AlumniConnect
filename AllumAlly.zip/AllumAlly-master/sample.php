$result = mysqli_query($conn,"INSERT INTO otps(otp,flag,created) VALUES ('" . $otp . "', 0, '" . date("Y-m-d H:i:s"). "')");
                $result1 = mysqli_query($conn,"SELECT * FROM otp_expiry WHERE otp='" . $_POST["otp"] . "' AND is_expired!=1 AND NOW() <= DATE_ADD(create_at, INTERVAL 24 HOUR)");
                $count  = mysqli_num_rows($result1);
                if(!empty($count)) {
                    if($_POST['otp']!="")
                    {
                        $result = mysqli_query($conn,"UPDATE otps SET flag = 1 WHERE otp = '" . $_POST["otp"] . "'");
                        mysqli_query($conn, "UPDATE admins set pwd='" . $_POST["newPassword"] . "' WHERE email='". $email ."'");
                        $_SESSION['message'] = "Password Changed successfully!";
                    }
                    else
                    {
                        $_SESSION['message'] = "Enter OTP!";
                    }
                } else {
                    $_SESSION['message'] = "Invalid OTP!";
                }   
            }

            $message = '<pre><p style="font-size:16px;"> OTP to change your password is: </p><strong><a style="text-decoration:none;"'.$otp.'</a></strong></pre>';
                   


               mysqli_query($conn, "UPDATE users set pwd='" . $_POST["newPassword"] . "' WHERE email='". $email ."'");
            $_SESSION['message'] = "Password Changed successfully!";