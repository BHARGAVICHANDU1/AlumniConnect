<?php 
session_start();

// connect to database
$host="localhost";  
$username="root";  
$password="";  
$db_name="alumni"; 

// Connect to server
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

else {
	$email = $_POST['email'];
	$query = "DELETE FROM members WHERE email='$email'";
	mysqli_query($con, $query);
	$_SESSION['msg']  = "Details deleted successfully";
	header('location: changeStudentDetails.php');
}