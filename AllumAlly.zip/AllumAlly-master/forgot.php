<?php
require_once "Mail.php";
$host1 = "ssl://smtp.gmail.com";
$from = "alumniupdates2020@gmail.com";
$to = "alumniupdates2020@gmail.com";
$port = "465";
$username = 'alumniupdates2020@gmail.com';
$password = 'alumni2020';
session_start();
if(isset($_POST['submit'])){
$email = $_POST['email'];
$type = $_POST['userType'];
if($type=="ss")
    $tbl = "userdb";
else if($type=="al")
    $tbl = "alumnidetails";
else
    $tbl = "admin";
$conn = mysqli_connect("localhost", "root", "", "alumni") or die("Connection Error: " . mysqli_error($conn));
$result = mysqli_query($conn, "SELECT * from " .$tbl. " WHERE email='". $email ."'");
$row = mysqli_fetch_array($result);
if(count($row)>0)
{
    $pwd = $row['pwd'];
    $subject = "Forgot Password";
    $message = '<pre><p style="font-size:16px;">Your current password is: </p><p style="font-size:16px; color:blue;">'.$pwd.'</p><br><p style="font-size:16px;">With Regards, <br>AllumAlly.</p></pre>';
    $message = wordwrap($message, 70);
    $headers = array ('From' => $from, 'To' => $to,'Subject' => $subject, 'MIME-Version' => '1.0','Content-Type' => 'text/html; charset=iso-8859-1');
    $smtp = Mail::factory('smtp', array ('host' => $host1, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password));
    $mail = $smtp->send($email, $headers, $message);
    $flag=0;    
    $_SESSION['send']=1;
    if (PEAR::isError($mail)) 
    {
        echo "<script>
                 alert('Request could not be processed. Please try again later!'); 
                 window.history.go(-1);
         </script>";
    }
    else
    {   echo "<script>
                 alert('Please check your mail'); 
                 window.history.go(-1);
         </script>";
    }

}  
}
?>


