<html>
<head>
<title>Update Data</title>
<link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  <link href="/apple-touch-icon.png" rel="apple-touch-icon">
<link rel="stylesheet" type="text/css" href="change_password_styles.css" />
</head>
<body>
    <form name="frmUpdate" method="post" action="alumniUpdate.php">
        <div style="width: 500px;">
            <div class="message"><?php if(isset($message)) { echo $message; } ?></div>
            <table border="0" cellpadding="10" cellspacing="0"
                width="500" align="center" class="tblSaveForm">
                <tr class="tableheader">
                    <td colspan="2">Update Data</td>
                </tr>
                <tr>
                    <td width="40%"><label>User id</label></td>
                    <td width="60%"><input type="text"
                        name="id" class="txtField" required="true"/><span class="required"></span></td>
                </tr>
                <tr>
                    <td width="40%"><label>Email</label></td>
                    <td width="60%"><input type="text"
                        name="email" class="txtField" /><span
                        id="email" class="required"></span></td>
                </tr>
                <tr>
                    <td><label>Phone No</label></td>
                    <td><input type="text" name="phno"
                        class="txtField" /><span id="phno"
                        class="required"></span></td>
                </tr>
                <td><label>Company</label></td>
                <td><input type="text" name="company"
                    class="txtField" /><span id="company"
                    class="required"></span></td>
                </tr>
				</tr>
                <td><label>Designation</label></td>
                <td><input type="text" name="designation"
                    class="txtField" /><span id="designation"
                    class="required"></span></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="submit"
                        value="Submit" class="btnSubmit"></td>
                </tr>
            </table>
        </div>
    </form>
</body>
</html>