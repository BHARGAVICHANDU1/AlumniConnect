<?php
//post

	$host="localhost"; // Host name 
	$username="root"; // Mysql username 
	$password=""; // Mysql password 
	$db_name="alumni"; // Database name 
	$tbl_name="new"; // Table name
	// Connect to server and select databse.
	$con=mysqli_connect("$host", "$username", "$password", "$db_name");
	session_start();
	require_once "Mail.php";

	$host1 = "ssl://smtp.gmail.com";
	$from = "alumniupdates2020@gmail.com";
	$port = "465";
	$username = 'alumniupdates2020@gmail.com';
	$password = 'alumni2020';
	
	if (mysqli_connect_errno()) 
	{
		$_SESSION['connect'] = "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else
	{	
		$sql="SELECT * FROM $tbl_name";
		$temp=$_POST['message1'];  
		$result=mysqli_query($con,$sql);
		$message = '<pre><p style="font-size:18px; color:black; font-family:Times New Roman;"">'.$temp.'</p><strong><a style="font-size:30px; font-family:Times New Roman; margin-left: 40%;" href="index.php">AllumAlly</a></strong><br><br><p style="font-size:18px; color:black; font-family:Times New Roman;">'.$_POST['message3'].'</p></pre>';
		
			$count=mysqli_num_rows($result);
			if($count>0)
			{
				$flag = 0;
				$cc = '';
				while($row=mysqli_fetch_array($result))
				{
					if(isset($to))
						$cc = $cc . $row['email']. ',';
					else
						$to = $row['email'];				
				}
				$cc = substr($cc, 0, -1);
				$subject = "Hello Alumni!";
				$headers = array ('From' => $from, 'To' => $to,'Subject' => $subject, 'MIME-Version' => '1.0','Content-Type' => 'text/html;charset=iso-8859-1', 'Cc' => $cc, 'Importance' => 'High');
				$smtp = Mail::factory('smtp',
						array ('host' => $host1,
					   'port' => $port,
					   'auth' => true,
					   'username' => $username,
					   'password' => $password));
				$mail = $smtp->send($to, $headers, $message);
				if (PEAR::isError($mail)) {
					$flag = 1;
				 	$_SESSION['error'] = $_SESSION['error'].",".$to;
				}
				if($flag==0)
				{
					$mydate = getdate(date("U"));
					$date = $mydate[weekday].','.$mydate[month].' '.$mydate[mday].','.$mydate[year];
					$time = date("h:i:s A");
					$sql = "INSERT INTO mails(dates,dtime) VALUES ('$date','$time')";
					if (mysqli_query($con,$sql)) {
						$_SESSION['add'] = true;
					} else {
					    $_SESSION['adderror'] = true;
					}
				}
			}
	    
	}
	unset($to);
	header("location:send.php");
?>

<html>
<body>
<div id="show" style="background-color: black; border: 1px solid white; opacity: 0.8;">
			<p style="color: white;"><?php echo $message; ?></p>
			<br><br>
			<button onclick="sendmail()" type="submit" style="background-color: #ABB0B1;color: white;padding: 12px 20px;margin-left: 60px;cursor: pointer;width: 30%;
			opacity: 0.9;">Send</button>
    		<button type="button" style="background-color: #ABB0B1;color: white;padding: 12px 20px;margin-left: 10px;border: none;cursor: pointer;
    		width: 30%;opacity: 0.9;" onclick="closeForm()">Cancel</button>
		</div>
		<script type="text/javascript">
			function closeForm() {
			    document.getElementById("show").style.display = "none";
			}

			function sendmail() {
			    <?php $_SESSION['flag']=1; ?> 
			}
		</script>
</body>
</html>
