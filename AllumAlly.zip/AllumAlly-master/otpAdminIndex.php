<?php
session_start();

  if (isset($_SESSION['message'])) {
    echo '<script type="text/javascript">alert("' . $_SESSION['message'] . '");</script>';
    unset($_SESSION['message']);
}

if(isset($_SESSION['otp']))
{

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicons -->
  <link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  <link href="/apple-touch-icon.png" rel="apple-touch-icon">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
<link rel="stylesheet" href="css/cSDstyles.css">
<link rel="stylesheet" href="css/matrix-media.css">
<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/jquery.gritter.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div id="header">
</div>
<!--close-Header-part--> 


<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i>Modify Users</a>
  <ul>
    <li class="active"><a href="#"><i class="icon icon-home"></i> <span>Modify Users</span></a> </li>
    <li><a href="changeStudentDetail.php"><i class="icon icon-tint"></i> <span>Update Alumni Details</span></a></li>
    <li><a href="send.php"><i class="icon-calendar"></i> <span>Alumni Reminder</span></a></li>
    <li><a id="change"><i class="icon icon-pencil"></i> <span>Change Password</span></a></li>
    <li><a href="logout.php"><i class="icon icon-share-alt"></i> <span>Logout</span></a></li>
  </ul>
</div>
<!--sidebar-menu-->
  
<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="adminIndex.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
<!--End-breadcrumbs-->

<div>
  <p class="above"> You can perform one of these operations on the registered users data - </p>
  <br>
</div>

<div>
    <button class="openBtn" id="myBtnA">Add a user</button>  
    <button class="openBtn" id="myBtnB">Delete a user</button> 
    <button class="openBtn" id="myBtnC">Show login credentials of users</button>
</div>

<div id="otps" class="modalotp">
    <div class="otp-content">
      <span class="close">&times;</span><br>
        <form name="frmChange" method="post" action="adminAction.php">
          <table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">
              <tr>
                <td><label style="font-family:'Times New Roman'; font-size: 17px;">OTP </label></td>
                <td><input type="password" name="otp" class="txtField" style="width: 100%;height: 40px;padding: 10px;margin: 5px 0 15px 0;display: inline-block;border: 1px solid #BCBCBC;background: white;" required/></td>
                </tr>
              <tr>
                    <td><p style="font-family:'Times New Roman'; color: brown; font-size: 13px;">(Check your mail for OTP)</p></td>
                </tr>
              <tr>
                    <td colspan="2"><button type="submit" class="submitbtn">Submit</button></td>
                </tr>
              </table>
        </form>
    </div>
</div>
</div>

<!--Footer-part-->
  <footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="copyright">
         &copy; 2019 <strong>AllumAlly</strong>. All Rights Reserved
      </div>
  </div>
    </div>
  </footer><!-- #footer -->

<!--end-Footer-part-->

<script type="text/javascript">
 
// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}


var modal1 = document.getElementById("otps");

var span1 = document.getElementsByClassName("close")[0];

span1.onclick = function() {
  window.location.replace('adminIndex.php');
}

</script>
</body>
</html>

<?php } 

else {
  echo '<script language="javascript">';
  echo 'window.location.href="adminIndex.php";';
  echo '</script>';
}

?>
