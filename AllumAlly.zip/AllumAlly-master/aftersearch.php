<?php
session_start();
$regno = $_POST['regno'];  
$name = $_POST['name'];
//$title = $_POST['title'];
$company = $_POST['company'];
$location = $_POST['location'];
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="alumni"; // Database name 
$tbl_name="alumnidetails"; // Table name
// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
	//$name = strtoupper($name);
	//$sql="SELECT * FROM $tbl_name WHERE name like '%".$name."%'";
	if(!empty($regno) and !empty($name) and !empty($company) and !empty($location))
	{
		$name = strtoupper($name);
		$location = strtoupper($location);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or name like '%".$name."%' or  company='$company' or location='$location'";
	}
	else if(!empty($regno) and empty($name) and empty($company) and empty($location))
	{
		
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno'";
	}
	else if(empty($regno) and !empty($name) and empty($company) and empty($location))
	{
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE name like '%".$name."%'";
	}
	else if(empty($regno) and empty($name) and !empty($company) and empty($location))
	{
		//$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE company='$company'";
	}
	else if(empty($regno) and empty($name) and empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$sql="SELECT * FROM $tbl_name WHERE location='$location'";
	}
	else if(!empty($regno) and !empty($name) and empty($company) and empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or name like '%".$name."%'";
	}
	else if(!empty($regno) and empty($name) and !empty($company) and empty($location))
	{
		
		//$location = strtoupper($location);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or company='$company'";
	}
	else if(!empty($regno) and empty($name) and empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or location='$location'";
	}
	else if(empty($regno) and !empty($name) and !empty($company) and empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE name like '%".$name."%' or company='$company'";
	}
	else if(empty($regno) and !empty($name) and empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE name like '%".$name."%' or location='$location'";
	}
	else if(empty($regno) and empty($name) and !empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE company='$company' or location='$location'";
	}
	else if(!empty($regno) and !empty($name) and !empty($company) and empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or name like '%".$name."%' or company='$company'";
	}
	else if(!empty($regno) and !empty($name) and empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or name like '%".$name."%' or location='$location'";
	}
	else if(!empty($regno) and empty($name) and !empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE userid='$regno' or company='$company' or location='$location'";
	}
	else if(empty($regno) and !empty($name) and !empty($company) and !empty($location))
	{
		
		//$location = strtoupper($location);
		$name = strtoupper($name);
		$sql="SELECT * FROM $tbl_name WHERE name like '%".$name."%' or company='$company' or location='$location'";
	}
	$result=mysqli_query($con,$sql);

	// Mysqli_num_row is counting table row
	$count=mysqli_num_rows($result);
	 
	if($count>0)
	{
		?>
		<html>
		<link rel="stylesheet" type="text/css" href="tablestyles.css">
		<link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  		<link href="/apple-touch-icon.png" rel="apple-touch-icon">

		<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
					<div class="table">
							<a href="userIndex.php">Back</a>
						<div><p style="margin-bottom: 10px;"></p></div>
						<div class="row header">
							<div class="cell"> Name </div>
							<div class="cell"> Roll No </div>
							<div class="cell"> Phone </div>
							<div class="cell"> Email </div>
							<div class="cell"> Company </div>
							<div class="cell"> Location </div>
						</div>

						<?php
						while($row = mysqli_fetch_assoc($result)) {
							$id = $row["userid"];
						?>

       					<div id=<?=$id?>  onclick="myFunc(this)" class="row data">
							<div class="cell" data-title="Name">
								<?php  echo $row["name"]  ?>
							</div>
							<div class="cell" data-title="Age">
								<?php echo $row["userid"] ?>
							</div>
							<div class="cell" data-title="Job Title">
								<?php  echo $row["phno"]  ?>
							</div>
							<div class="cell" data-title="Location">
								<?php  echo $row["email"]  ?>
							</div>
							<div class="cell">
								<?php  echo $row["company"]  ?>
							</div>
							<div class="cell">
								<?php  echo $row["location"]  ?>
							</div>
						</div>
						<?php
							}
						?>
						<script>
						    function myFunc(element){
								location.href = "output.php?id="+element.id;
								//alert(element.id);
							    //var content = parent.querySelector("div");
							    //alert(content.id);
							}
						</script>
					</div>
				</div>
			</div>
		</div>
		</html>
		<?php
	}
	else 
	{
		//Sending API request
		session_start();
		$_SESSION['msg'] = "Sorry! Details of are not available";
        header('Location: ./userindex.php');		
	}
}
?>