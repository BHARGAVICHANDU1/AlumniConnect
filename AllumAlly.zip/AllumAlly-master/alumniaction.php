<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "alumni") or die("Connection Error: " . mysqli_error($conn));
$email=$_SESSION['user'];

if(isset($_SESSION["otp"]))
{
        if($_SESSION["otp"] == $_POST['otp']) {
            mysqli_query($conn, "UPDATE alumnidetails set pwd='" .$_SESSION['np'] . "' WHERE email='". $email ."'");
            $_SESSION['message'] = "Password Changed successfully!";
            unset($_SESSION["otp"]);
            header('Location: ./alumniIndex.php');
        }
        else {
            $_SESSION['message'] = "Invalid OTP!";
            header('Location: ./otpAlumniIndex.php');
        }
}

else
{
if (count($_POST) > 0) {
    $result = mysqli_query($conn, "SELECT * from alumnidetails WHERE email='". $email ."'");
    $row = mysqli_fetch_array($result);
    if(count($row)>0){
        if ($_POST['newPassword']!=$_POST['confirmPassword'])
        {
            $_SESSION['message'] = "Passwords did not match! Please try again.";
            header('Location: ./alumniIndex.php');
        }
        else if ($_POST["currentPassword"] == $row["pwd"]) {
            $_SESSION['np'] = $_POST["newPassword"];
            $otp = rand(100000,999999);
            require_once "Mail.php";
            $host1 = "ssl://smtp.gmail.com";
            $from = "alumniupdates2020@gmail.com";
            $to = $email;
            $port = "465";
            $username = 'alumniupdates2020@gmail.com';
            $password = 'alumni2020';
            $message = '<pre><p style="font-size:16px;"> OTP to change your password is: </p><strong><a style="text-decoration:none; font-size:20px; margin-left:10px;">'.$otp.'</a></strong><p>This is available for the current session.<br>----------------------------</p><p style="font-size:20px;color:blue;">AllumAlly</p></pre>';
            $subject = "Password change request";
            $headers = array ('From' => $from, 'To' => $to,'Subject' => $subject, 'MIME-Version' => '1.0','Content-Type' => 'text/html; charset=iso-8859-1');
            $smtp = Mail::factory('smtp', array ('host' => $host1, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password));
            $mail = $smtp->send($email, $headers, $message);
            if (PEAR::isError($mail)) 
            {
                $_SESSION['message'] = "An error has occurred. Please try again later!";
                header('Location: ./alumniIndex.php');
            }
            else
            {   
                $_SESSION['otp'] = $otp;
                header('Location: ./otpAlumniIndex.php');
            }
            
        } 
        else {
            $_SESSION['message']="Current password entered is incorrect. Try again!";
            header('Location: ./alumniIndex.php');
        }
        
    }
    else{
        $result = mysqli_query($conn, "SELECT * from alumnidetails WHERE email='". $email ."'");
        $row = mysqli_fetch_array($result);
        if ($_SESSION['output']==false)
        {
            $_SESSION['message'] = "Passwords did not match! Please try again.";
        }
        if ($_POST["currentPassword"] == $row["pwd"]) {
            mysqli_query($conn, "UPDATE alumnidetails set pwd='" . $_POST["newPassword"] . "' WHERE email='". $email ."'");
            $_SESSION['message'] = "Password Changed successfully!";
        } else {
            $_SESSION['message']="Current password entered is incorrect. Try again!";
        }
        header('Location: ./alumniIndex.php');
    }
}
}
?>