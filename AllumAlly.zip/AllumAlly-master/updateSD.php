<?php 
session_start();

// connect to database
$host="localhost";  
$username="root";  
$password="";  
$db_name="alumni"; 

// Connect to server
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

else {
	$name = $_POST['name'];
	$name = strtoupper($name);
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	if(empty($email) && empty($phone)) {
    	$_SESSION['message'] = "Empty fields";
    }
    else
    {
    	if(empty($email) && isset($phone)) {	
    		$query = "UPDATE members SET phone='$phone' WHERE name='$name'";
    	}
    	else if(empty($phone) && isset($email)) {
    		$query = "UPDATE members SET email='$email' WHERE name='$name'";
    	}
    	else {
    		$query = "UPDATE members SET phone='$phone' and email='$email' WHERE name='$name'";
    	}
		if(mysqli_query($con, $query)) {
			$_SESSION['message']  = "Details updated successfully";
		}
		else {
			$_SESSION['message']  = "Details could not be updated at present. Try again later!";
		}
		
    }
	header('location: changeStudentDetails.php');
}