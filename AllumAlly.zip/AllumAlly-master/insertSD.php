<?php 
session_start();

// connect to database
$host="localhost";  
$username="root";  
$password="";  
$db_name="alumni"; 

// Connect to server
$con=mysqli_connect("$host", "$username", "$password", "$db_name");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

else {
	$userid = $_POST['regno'];
	$name = $_POST['name'];
	$name = strtoupper($name);
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$company = $_POST['company'];
	$location = $_POST['location'];
	$query = "INSERT INTO alumnidetails(userid,name, email, phno,company,location) VALUES('$userid','$name', '$email', '$phone','$company','$location')";
	mysqli_query($con, $query);
	$_SESSION['msg']  = "Details inserted successfully";
	header('location: adminIndex.php');
}