<?php
session_start();
// Load the database configuration file
$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "alumni";

// Create database connection
$db = mysqli_connect("$dbHost", "$dbUsername", "$dbPassword", "$dbName");

if (mysqli_connect_errno()) {
    $_SESSION['qstring'] = 'Failed to connect to MySQL!';
}

else{

if(isset($_POST['importSubmit'])){
    // Allowed mime types
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    // Validate whether selected file is a CSV file
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)){
        
        // If the file is uploaded
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            // Open uploaded CSV file with read-only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            // Skip the first line
            fgetcsv($csvFile);
            
            // Parse data from CSV file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE){
                // Get row data
                $name   = $line[0];
                $phone  = $line[1];
                $email  = $line[2];
                
                // Check whether member already exists in the database with the same email
                $prevQuery = "INSERT into members(name,phone,email) values('".$name."','".$phone."','".$email."')";
                $prevResult = mysqli_query($db,$prevQuery);
                
            }
            
            // Close opened CSV file
            fclose($csvFile);
            $_SESSION['qstring'] = 'Successfully imported!';
		}else{
            $_SESSION['qstring'] = 'File could not be uploaded! Please try again';
        }
    }else{
        $_SESSION['qstring'] = 'Invalid file!\\nRequired type: csv';
    }
}
}
header('location: changeStudentDetails.php');
?>