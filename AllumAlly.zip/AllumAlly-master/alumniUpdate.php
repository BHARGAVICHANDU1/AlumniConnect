<?php
$email = $_POST['email'];
$phno = $_POST['phno'];
$company = $_POST['company'];
$location = $_POST['location'];
$host="localhost";
$username="root";
$password="";
$dbname="alumni";
$tb_name="alumnidetails";
$con = mysqli_connect("$host","$username","$password","$dbname");
session_start();

if(mysqli_connect_errno())
{
	echo "Failed to connect to MySQL".mysqli_connect-errno();
}
else
{
	if(empty($phno) and empty($company) and empty($location))
	{
		$_SESSION['m']="Enter atleast two fields.";
	}
	else
	{
		//$sql="SELECT * FROM $tbl_name WHERE userid='$userId'";
		 $result = mysqli_query($con, "SELECT * from $tb_name WHERE email='$email'");
		 $count=mysqli_num_rows($result);
		 if($count===1)
		 {
			//if(!empty($email))
				//mysqli_query($con, "UPDATE $tb_name set email='" . $_POST["email"] . "' WHERE userid='$userId'");
			if(!empty($phno))
				mysqli_query($con, "UPDATE $tb_name set phno='" . $_POST["phno"] . "' WHERE email='$email'");
			if(!empty($company))
				mysqli_query($con, "UPDATE $tb_name set company='" . $_POST["company"] . "' WHERE email='$email'");
			if(!empty($location))
				mysqli_query($con, "UPDATE $tb_name set location='" . $_POST["location"] . "' WHERE email='$email'");
			$_SESSION['m']="Details Updated Successfully";
		 }
		 else
		 {
				$_SESSION['m']="Email is not available! Contact the admin.";
		 }
	}
	header("location:alumniIndex.php");
	exit(); 
}
?>