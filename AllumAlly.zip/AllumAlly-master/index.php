<?php
session_start();
if(isset($_SESSION['send']))
{
  header("Refresh: 0");
  unset($_SESSION['send']);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Allum Ally</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link type="image/png" sizes="32x32" href="img/favicon-32x32.png" rel="icon">
  <link href="/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

</head>

<body>

  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        <h1><a href="#intro" class="scrollto">AllumAlly</a></h1>
      </div>
<!-- Login Form -->
  <div class="form-popup" id="loginS">
    <div class="popup">
   <form action="./verifylogin.php" method="post">
    <b>User Id</b>
    <input type="email" placeholder="Enter Id" name="email" required>
    <b>Password</b>
    <input type="password" placeholder="Enter Password" name="pwd" required>
    <button type="submit" class="registerbtn">Login</button>
    <button type="button" class="cancel" onclick="closeForm()">Cancel</button>
    </form>
	<button onclick="forgot()" class="forgot">Forgot Password?</button>
    </div>
  </div>

<div class="form-popup" id="loginA">
    <div class="popup">
   	<form action="./verifyadminlogin.php" method="post">
    <b>User Id</b>
    <input type="email" placeholder="Enter Id" name="email" required>
    <b>Password</b>
    <input type="password" placeholder="Enter Password" name="pwd" required>
    <button type="submit" class="registerbtn">Login</button>
    <button type="button" class="cancel" onclick="closeForm()">Cancel</button>
    </form>
    <button onclick="forgot()" class="forgot">Forgot Password?</button>
    </div>
</div>
<div class="form-popup" id="loginAlumni">
    <div class="popup">
   <form action="./verifyAlumni.php" method="post">
    <b>User Id</b>
    <input type="email" placeholder="Enter Id" name="email" required>
    <b>Password</b>
    <input type="password" placeholder="Enter Password" name="pwd" required>
    <button type="submit" class="registerbtn">Login</button>
    <button type="button" class="cancel" onclick="closeForm()">Cancel</button>
    </form>
	<button onclick="forgot()" class="forgot">Forgot Password?</button>
     </div>
 </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">Home</a></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#contact">Contact</a></li>
      <li>
        <div class="dropdown">
        <button class="open-button" onmouseover="closeForm()">Login</button>
          <div class="dropdown-content">
            <a onclick="openForm1()">Student/Satff</a>
          <a onclick="openForm3()">Alumni</a>
            <a onclick="openForm2()">Admin</a>
          
        </div>
      </div>
      </li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  
  <div id="forgot" class="modal1">

  <!-- Modal content -->
  <div class="forgot-content">
    <span class="close2">&times;</span><br>
	<form action="./forgot.php" method="post">
		<input type="radio" name="userType" value="ss">
	  	<label>Student/Staff</label> &nbsp; &nbsp; &nbsp; &nbsp;
	 	<input type="radio" name="userType" value="al">
	  	<label>Alumni</label> &nbsp; &nbsp; &nbsp; &nbsp;
	  	<input type="radio" name="userType" value="ad">
	  	<label>Admin</label><br>
	  	<input type="email" placeholder="Email id" name="email" required><br>
		<button type="submit" class="registerbtn" name="submit">Submit</button>
		<button type="button" class="cancel" onclick="closeForm()">Cancel</button>
	</form>    
  </div>
</div>

  
  <script>
  function openForm1() {
    document.getElementById("loginS").style.display = "block";
  }

  function openForm2() {
    document.getElementById("loginA").style.display = "block";
  }
  function openForm3() {
    document.getElementById("loginAlumni").style.display = "block";
  }

  function closeForm() {
    document.getElementById("loginA").style.display = "none";
    document.getElementById("loginS").style.display = "none";
    document.getElementById("loginAlumni").style.display = "none";
  }
  
  var modal1 = document.getElementById("forgot");
  function forgot() {
  		document.getElementById("loginA").style.display = "none";
    	document.getElementById("loginS").style.display = "none";
    	document.getElementById("loginAlumni").style.display = "none";
  		modal1.style.display = "block";
  }
  
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
var span = document.getElementsByClassName("close2")[0];
span.onclick = function() {
  modal1.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal1) {
    modal1.style.display = "none";
  }
}

  </script>

  <!-- End of Login form -->
  
  
  
  </header><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active">
     
            <div class="carousel-background"><img src="./3.jpg" alt=""></div>

            	<div>
				<?php
				if(isset($_SESSION['errormsg']))
				  {
				  	?>
				  	<div id="hideMe" class="alert1">
				  	<p class="msg"><b><?php echo $_SESSION['errormsg']; ?></b></p>
					</div>
				<?php
				unset($_SESSION['errormsg']);
				  }
				?>
			</div>

            <div class="carousel-container">

              <div class="carousel-content">      
                <h2>Alumni Connect!</h2>
                <p>Alumni are a great resource every educational institution can take pride in. Often the students of an
institute seek professional help from their alumni. Be it a job referral or a friendly face in a fairly
strange place of work, alumni comes to help.</p>
                </div>
            </div>
          </div>

        </div>
</ol>
        
      </div>
    </div>
  </section><!-- #intro -->

  <main id="main">

    <!--==========================
      Featured Services Section
    ============================-->
    <section id="featured-services">
      <div class="container">
        <div class="row">

          <div class="col-lg-5 box box-bg">
            <i class="ion-ios-people"></i>
            <h4 class="title"><a>Re-union</a></h4>
            <p class="description">You can collect information about your alumni to gather them for events.</p>
          </div>

      <div class="col-lg-2 box">
      </div>
      
          <div class="col-lg-5 box box-bg">
            <i class="ion-ios-book"></i>
            <h4 class="title"><a>Career Advice</a></h4>
            <p class="description">You can get good career suggestions from your seniors.</p>
          </div>

          
        </div>
      </div>
    </section><!-- #featured-services -->

    <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

        <header class="section-header">
          <h3>About Us</h3>
          <p>Allum Ally helps you to connect with your college's alumni network. This website helps in connecting with the alumni of Vasireddy Venkatadri Institute of Technology. The records of them at the institute at the time of their graduation are considered and we provide a feature for the alumni to update their details by logging into AllumAlly.
      </p>
        </header>

        <div class="row about-cols">

          <div class="col-md-6 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                <img src="img/mission3.jpeg" style="width:100%;" alt="Image unavailable" class="img-fluid">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a>Our Mission</a></h2>
              <p>A group of members collaborate to strengthen both the alumni relations and the upcoming placements of the undergraduates.
              </p>
            </div>
          </div>

          <div class="col-md-6 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                <img src="img/vision2.jpeg" style="width:100%;" alt="Image unavailable" class="img-fluid">
                <div class="icon"><i class="ion-ios-eye-outline"></i></div>
              </div>
              <h2 class="title"><a>Our Vision</a></h2>
              <p>A platform based on building a relationship with the alumni of the respective institute.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      Contact Section
    ============================-->
    <section id="contact" class="section-bg wow fadeInUp">
      <div class="container">

        <div class="section-header">
          <h3>Contact Us</h3>
        </div>

        <div class="row contact-info">

          <div class="col-md-6">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855">+91 9435789685</a></p>
            </div>
          </div>

          <div class="col-md-6">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="mailto:alumniupdates2020@gmail.com">alumniupdates2020@gmail.com</a></p>
            </div>
          </div>

        </div>
    
    <div class="section-header">
          <h3>Drop a message</h3>
        </div>

        <div class="form">
          <form action="./secure_email.php" method="post" class="contactForm">
            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter your name" required />
               </div>
        
             <div class="form-group col-md-6">
                <input type="email" name="email" class="form-control" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required />
              </div>
  
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required />
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" required></textarea>
            </div>
            <div class="text-center"><button name='submit' type="submit" value="Submit">Send</button></div>
          </form>
          
        </div>
      </div>
    </section><!-- #contact -->

  </main>

  <!--==========================
    Footer
  ============================-->
  <!--<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-2 col-md-6 social-links">
             <a href="mailto:alumniupdates2020@gmail.com" class="google-plus"><i class="fa fa-google-plus"></i></a>
          </div>


          <div class="col-lg-8 col-md-6">
          	 <div class="container">
		      <div class="copyright">
		         &copy; 2020 <strong>AllumAlly</strong>. All Rights Reserved
		      </div>
		    </div>
      	  </div>

      	  <div class="col-lg-2 col-md-6">
      	  	<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
        </div>
      </div>
    </div>

   
  </footer>--> <!-- #footer -->
  
  <footer id="footer">
   <div class="footer-top">
     <div class="container">
       <div class="row">

         <div class="col-lg-2 col-md-5 social-links">
            <a href="alumniupdates2020@gmail.com" class="google-plus"><i class="fa fa-google-plus"></i></a>
         </div>


         <div class="col-lg-8 col-md-5">
          <div class="container">
     <div class="copyright">
        &copy; 2020 <strong>AllumAlly</strong>. All Rights Reserved
     </div>
   </div>
       </div>

       <div class="col-lg-2 col-md-2">
        <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
       </div>
     </div>
   </div>

 
 </footer><!-- #footer -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/touchSwipe/jquery.touchSwipe.min.js"></script>
 
  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>